import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtQuick.Shapes

import org.qfield
import org.qgis
import Theme

import "qrc:/qml" as QFieldItems

Item {
  id: plugin

  property var mainWindow: iface.mainWindow()
  property var mapCanvas: iface.mapCanvas()
  property var mapCanvasMap: iface.findItemByObjectName("mapCanvasMap")
  property var featureForm: iface.findItemByObjectName('featureForm')
  
  property var roomsLayer: undefined
  property var scheduleLayer: undefined

  Component.onCompleted: {
    roomsLayer = qgisProject.mapLayersByName("Conference")[0];
    scheduleLayer = qgisProject.mapLayersByName("Schedule")[0];
    ExpressionContextUtils.setLayerVariable(roomsLayer, "current_floor", "");
    mapCanvas.mapSettings.isTemporal = !mapCanvas.mapSettings.isTemporal
  }
  
  Connections {
    target: featureForm.selection
    enabled: sliderContainer.expanded

    function onFocusedItemChanged() {
      let feature_floor = -1;
      if (featureForm.selection.focusedLayer === roomsLayer) {
        feature_floor = Number(featureForm.selection.focusedFeature.attribute("floorName"));
      } else if (featureForm.selection.focusedLayer === scheduleLayer) {
        feature_floor = Number(featureForm.selection.focusedFeature.attribute("rooms_details_floor")) + 1;
      }
      if (feature_floor >= 0) {
        floorSlider.value = feature_floor;
      }
    }
  }
  
  Rectangle {
    id: sliderContainer
    parent: mapCanvas
    anchors.left: parent.left
    anchors.leftMargin: 5
    anchors.verticalCenter: parent.verticalCenter
    width: 48
    height: expanded ? (parent.height) * 0.4 : width
    radius: width / 2
    color: "#AA333333"
    clip: true

    Behavior on height  {
      PropertyAnimation {
        easing.type: Easing.OutQuart
      }
    }

    property bool expanded: false

    ColumnLayout {
      anchors.fill: parent
      spacing: 0

      Text {
        Layout.fillWidth: true
        Layout.preferredHeight: sliderContainer.expanded ? 48 : 0
        color: "white"
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignBottom
        font: Theme.tipFont
        text: "<b>Flr.</b><br>" + (floorSlider.value - 1)
      }

      Slider {
        id: floorSlider
        Layout.preferredHeight: sliderContainer.expanded ? 48 : 0
        Layout.fillWidth: true
        Layout.fillHeight: true
        Layout.topMargin: 0
        orientation: Qt.Vertical
        from: 0
        to: 7
        stepSize: 1
        value: 1

        onValueChanged: {
          ExpressionContextUtils.setLayerVariable(roomsLayer, "current_floor", value);
          mapCanvas.mapSettings.isTemporal = !mapCanvas.mapSettings.isTemporal
        }
      }

      QfToolButton {
        Layout.preferredWidth: 48
        Layout.preferredHeight: 48
        round: true

        bgcolor: Theme.toolButtonBackgroundColor
        iconSource: Qt.resolvedUrl("assets/QGIS_logo_new.svg")

        onClicked: {
          sliderContainer.expanded = !sliderContainer.expanded;

          if (sliderContainer.expanded) {
            flatLayerTree.mapTheme = "Conferencing"
            let geometry = GeometryUtils.createGeometryFromWkt("POLYGON((1800474 8091775,1801358 8091775,1801358 8092546,1800474 8092546,1800474 8091775))");
            let extent = GeometryUtils.boundingBox(geometry);
            mapCanvas.mapSettings.setExtent(extent , true);

            ExpressionContextUtils.setLayerVariable(roomsLayer, "current_floor", 1);
            if (floorSlider.value !== 1) {
              floorSlider.value = 1;
            } else {
              mapCanvas.mapSettings.isTemporal = !mapCanvas.mapSettings.isTemporal
            }
          } else {
            flatLayerTree.mapTheme = "All"
            ExpressionContextUtils.setLayerVariable(roomsLayer, "current_floor", "");
            mapCanvas.mapSettings.isTemporal = !mapCanvas.mapSettings.isTemporal
          }
        }
      }
    }
  }
  
  Repeater {
    id: busesRepeater
    parent: mapCanvas

    model: []

    Item {
      MapToScreen {
        id: mapToScreenStart
        mapSettings: mapCanvas.mapSettings
        mapPoint: GeometryUtils.reprojectPoint(GeometryUtils.point(modelData["Longitude"], modelData["Latitude"]), CoordinateReferenceSystemUtils.wgs84Crs(), mapCanvas.mapSettings.destinationCrs)
      }

      width: 40
      height: width

      x: mapToScreenStart.screenPoint.x - width / 2
      y: mapToScreenStart.screenPoint.y - width / 2

      Shape {
        width: parent.width
        height: parent.height

        rotation: modelData["Direction"] + mapCanvas.mapSettings.rotation
        transformOrigin: Item.Center

        ShapePath {
          strokeWidth: 1
          strokeColor: "white"
          strokeStyle: ShapePath.SolidLine
          joinStyle: ShapePath.MiterJoin
          fillColor: "#ff0000"

          startX: 20
          startY: 1

          PathQuad {
            x: 36
            y: 20
            controlX: 36
            controlY: 15
          }
          PathQuad {
            x: 20
            y: 39
            controlX: 36
            controlY: 36
          }
          PathQuad {
            x: 4
            y: 20
            controlX: 4
            controlY: 36
          }
          PathQuad {
            x: 20
            y: 1
            controlX: 4
            controlY: 15
          }
        }
      }


      Text {
        anchors.top: parent.top
        anchors.left: parent.left
        width: parent.width
        height: parent.height
        text: modelData["LineName"]
        color: "#ffffff"
        font.pointSize: 9
        font.bold: true
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
      }
    }
  }

  Timer {
    interval: 5000
    repeat: true
    running: true

    onTriggered:  {
      let request = new XMLHttpRequest();
      request.onreadystatechange = () => {
        if (request.readyState === XMLHttpRequest.DONE) {
          let json = JSON.parse(request.response)
          let bus = {};
          let array = [];
          let currentLineNb = 0;
          for(const line of json) {
            if (currentLineNb == 12) {
              array.push(bus);

              currentLineNb = 0;
              bus = {}
            }
            
            if (currentLineNb == 1) {
              bus["LineName"] = line;
            } else if (currentLineNb == 8) {
              bus["Latitude"] = line;
            } else if (currentLineNb == 9) {
              bus["Longitude"] = line;
            } else if (currentLineNb == 10) {
              bus["Direction"] = line;
            }

            currentLineNb++
          }
          if (bus["LineName"] !== undefined) {
            array.push(bus);
          }

          busesRepeater.model = array;
        }
      }

      const url = "https://posroi.ostgotatrafiken.se/posroi/get?bounds=58.56425067621206%2C16.059088819372867%2C58.606750965598025%2C16.38764869486115&filterInBounds=&filterNoBounds=";
      request.open("GET", url);
      request.send();
    }
  }
}
