QField templates © 2025 by QFieldCloud GmbH are licensed under  
[Creative Commons Attribution 4.0 International (CC BY 4.0)](https://creativecommons.org/licenses/by/4.0/).

### What this means

✅ You can use, share, and adapt these templates — even commercially.  
📌 Just give proper credit to QFieldCloud GmbH.
